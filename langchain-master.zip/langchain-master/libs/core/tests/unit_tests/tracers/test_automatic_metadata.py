"""Test automatic tool call count storage in tracers."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from langchain_core.messages import AIMessage
from langchain_core.messages.tool import ToolCall
from langchain_core.outputs import ChatGeneration, LLMResult
from langchain_core.tracers.core import _TracerCore
from langchain_core.tracers.schemas import Run
from langchain_core.utils._gateway import GATEWAY_METADATA_RESPONSE_KEY


class MockTracerCore(_TracerCore):
    """Mock tracer core for testing LLM run completion."""

    def __init__(self) -> None:
        super().__init__()

    def _persist_run(self, run: Run) -> None:
        """Mock implementation of _persist_run."""


def test_complete_llm_run_automatically_stores_tool_call_count() -> None:
    """Test that `_complete_llm_run` automatically stores tool call count."""
    tracer = MockTracerCore()

    run = MagicMock(spec=Run)
    run.id = "test-llm-run-id"
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}

    tracer.run_map[str(run.id)] = run

    tool_calls = [
        ToolCall(name="search", args={"query": "test"}, id="call_1"),
        ToolCall(name="calculator", args={"expression": "2+2"}, id="call_2"),
    ]
    message = AIMessage(content="Test", tool_calls=tool_calls)
    generation = ChatGeneration(message=message)
    response = LLMResult(generations=[[generation]])

    # Complete the LLM run (this should trigger automatic metadata storage)
    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert "tool_call_count" in completed_run.extra
    assert completed_run.extra["tool_call_count"] == 2


def test_complete_llm_run_handles_no_tool_calls() -> None:
    """Test that `_complete_llm_run` handles runs with no tool calls gracefully."""
    tracer = MockTracerCore()

    run = MagicMock(spec=Run)
    run.id = "test-llm-run-id-no-tools"
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}

    tracer.run_map[str(run.id)] = run

    message = AIMessage(content="No tools here")
    generation = ChatGeneration(message=message)
    response = LLMResult(generations=[[generation]])

    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    # Verify tool call count is not stored when there are no tool calls
    assert "tool_call_count" not in completed_run.extra


def test_complete_llm_run_handles_empty_generations() -> None:
    """Test that `_complete_llm_run` handles empty generations gracefully."""
    tracer = MockTracerCore()

    run = MagicMock(spec=Run)
    run.id = "test-llm-run-id-empty"
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}

    tracer.run_map[str(run.id)] = run

    response = LLMResult(generations=[[]])

    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert "tool_call_count" not in completed_run.extra


def test_complete_llm_run_counts_tool_calls_from_multiple_generations() -> None:
    """Test that tool calls are counted from multiple generations."""
    tracer = MockTracerCore()

    run = MagicMock(spec=Run)
    run.id = "test-llm-run-id-multi"
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}

    tracer.run_map[str(run.id)] = run

    # Create multiple generations with tool calls
    tool_calls_1 = [ToolCall(name="search", args={"query": "test"}, id="call_1")]
    tool_calls_2 = [
        ToolCall(name="calculator", args={"expression": "2+2"}, id="call_2"),
        ToolCall(name="weather", args={"location": "NYC"}, id="call_3"),
    ]
    gen1 = ChatGeneration(message=AIMessage(content="Gen1", tool_calls=tool_calls_1))
    gen2 = ChatGeneration(message=AIMessage(content="Gen2", tool_calls=tool_calls_2))
    response = LLMResult(generations=[[gen1], [gen2]])

    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert completed_run.extra["tool_call_count"] == 3


def test_complete_llm_run_handles_null_tool_calls() -> None:
    """Test that `_complete_llm_run` handles null `tool_calls` gracefully."""
    tracer = MockTracerCore()

    run = MagicMock(spec=Run)
    run.id = "test-llm-run-id-null-tools"
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}

    tracer.run_map[str(run.id)] = run

    message = AIMessage(content="Test with null tool_calls")
    generation = ChatGeneration(message=message)
    # Bypass Pydantic validation by directly setting attribute
    object.__setattr__(message, "tool_calls", None)
    response = LLMResult(generations=[[generation]])

    # Should not raise TypeError from len(None)
    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert "tool_call_count" not in completed_run.extra


def _make_run(run_id: str) -> Run:
    run = MagicMock(spec=Run)
    run.id = run_id
    run.run_type = "llm"
    run.extra = {}
    run.outputs = {}
    run.events = []
    run.end_time = None
    run.inputs = {}
    return run


def test_complete_llm_run_attaches_gateway_metadata() -> None:
    """Gateway metadata on `generation_info` is promoted to run metadata."""
    tracer = MockTracerCore()
    run = _make_run("test-gateway-run-id")
    tracer.run_map[str(run.id)] = run

    gateway_info = {"provider": "openai", "model": "gpt-5.6-sol"}
    message = AIMessage(content="Test")
    response = LLMResult(
        generations=[
            [
                ChatGeneration(
                    message=message,
                    generation_info={GATEWAY_METADATA_RESPONSE_KEY: gateway_info},
                )
            ]
        ]
    )

    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert completed_run.extra["metadata"] == {
        "ls_gateway_info": gateway_info,
        "ls_model_name": gateway_info["model"],
        "ls_provider": gateway_info["provider"],
    }


def test_complete_llm_run_no_gateway_metadata() -> None:
    """No gateway metadata is attached when the response carries none."""
    tracer = MockTracerCore()
    run = _make_run("test-no-gateway-run-id")
    tracer.run_map[str(run.id)] = run

    message = AIMessage(content="Test", response_metadata={"model_provider": "openai"})
    response = LLMResult(generations=[[ChatGeneration(message=message)]])

    completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert "metadata" not in completed_run.extra


def test_errored_llm_run_attaches_gateway_metadata() -> None:
    """Gateway metadata is attached on the error path too."""
    tracer = MockTracerCore()
    run = _make_run("test-gateway-error-run-id")
    tracer.run_map[str(run.id)] = run

    gateway_info = {"error": "rate_limit_exceeded"}
    message = AIMessage(content="")
    response = LLMResult(
        generations=[
            [
                ChatGeneration(
                    message=message,
                    generation_info={GATEWAY_METADATA_RESPONSE_KEY: gateway_info},
                )
            ]
        ]
    )

    errored_run = tracer._errored_llm_run(
        error=ValueError("boom"), run_id=run.id, response=response
    )

    assert errored_run.extra["metadata"]["ls_gateway_info"] == gateway_info


@pytest.mark.parametrize("errored", [False, True])
@pytest.mark.parametrize(
    ("gateway_info", "expected_identity"),
    [
        pytest.param(
            {"model": "resolved-model", "provider": "amazon_bedrock"},
            {"ls_model_name": "resolved-model", "ls_provider": "amazon_bedrock"},
            id="resolved-identity",
        ),
        pytest.param(
            {"model": "resolved-model", "selected_model": "configured-model"},
            {"ls_model_name": "resolved-model"},
            id="model-only",
        ),
        pytest.param(
            {"provider": "amazon_bedrock"},
            {"ls_provider": "amazon_bedrock"},
            id="provider-only",
        ),
        pytest.param({}, {}, id="empty"),
        pytest.param({"error": "rate_limit_exceeded"}, {}, id="error-only"),
        pytest.param({"selected_model": "configured-model"}, {}, id="selected-only"),
        pytest.param({"model": None, "provider": None}, {}, id="null"),
        pytest.param({"model": "", "provider": ""}, {}, id="empty-strings"),
        pytest.param({"model": " \t\n", "provider": "\n "}, {}, id="whitespace-only"),
        pytest.param(
            {"model": " resolved-model\n", "provider": "\tamazon_bedrock "},
            {"ls_model_name": "resolved-model", "ls_provider": "amazon_bedrock"},
            id="surrounding-whitespace",
        ),
        pytest.param({"model": 42, "provider": ["openai"]}, {}, id="invalid-types"),
        pytest.param(
            {"model": False, "provider": "amazon_bedrock"},
            {"ls_provider": "amazon_bedrock"},
            id="invalid-model-valid-provider",
        ),
        pytest.param(
            {"model": "resolved-model", "provider": {}},
            {"ls_model_name": "resolved-model"},
            id="valid-model-invalid-provider",
        ),
    ],
)
def test_gateway_metadata_overrides_request_identity(
    gateway_info: dict[str, object],
    expected_identity: dict[str, str],
    *,
    errored: bool,
) -> None:
    """Only valid returned identity fields override request-time tracing metadata."""
    tracer = MockTracerCore()
    run = _make_run("test-gateway-identity-run-id")
    original_metadata = {
        "ls_model_name": "requested-model",
        "ls_provider": "openai",
        "custom": "preserved",
    }
    run.extra = {"metadata": original_metadata.copy()}
    tracer.run_map[str(run.id)] = run
    response = LLMResult(
        generations=[
            [
                ChatGeneration(
                    message=AIMessage(content="Test"),
                    generation_info={GATEWAY_METADATA_RESPONSE_KEY: gateway_info},
                )
            ]
        ]
    )

    if errored:
        completed_run = tracer._errored_llm_run(
            error=ValueError("boom"), run_id=run.id, response=response
        )
    else:
        completed_run = tracer._complete_llm_run(response=response, run_id=run.id)

    assert completed_run.extra["metadata"] == {
        **original_metadata,
        **expected_identity,
        "ls_gateway_info": gateway_info,
    }
